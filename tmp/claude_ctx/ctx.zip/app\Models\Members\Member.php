<?php

namespace App\Models\Members;

use App\Models\Billing\Charge;
use App\Models\Catalogs\City;
use App\Models\Catalogs\Country;
use App\Models\Catalogs\MaritalStatus;
use App\Models\Catalogs\State;
use App\Models\Memberships\MembershipAccount;
use App\Models\Memberships\MembershipAccountMember;
use App\Models\Members\ClinicalHistory;
use App\Models\User;
use App\Traits\SerializesDates;
use Carbon\Carbon;
use Database\Factories\MemberFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    use HasFactory, SerializesDates;

    protected $guarded = ['id', 'created_at', 'updated_at'];
    protected $table = 'members.members';
    protected $connection = 'pgsql';
    protected $appends = ['full_name', 'age'];

    /** Valores válidos: 'H' (hombre) o 'M' (mujer) */
    public const GENDERS = ['H', 'M'];

    public function scopeByClub($query, $clubId)
    {
        return $query->whereHas('accounts', function ($q) use ($clubId) {
            $q->where('club_id', $clubId)
            ->where('status', 'active');
        });
    }

    protected static function newFactory(): MemberFactory
    {
        return MemberFactory::new();
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function accountMemberships()
    {
        return $this->hasMany(MembershipAccountMember::class, 'member_id');
    }

    public function accounts()
    {
        return $this->belongsToMany(MembershipAccount::class,
            'memberships.account_members',
            'member_id',
            'membership_account_id'
        );
    }

    public function addresses()
    {
        return $this->hasMany(Address::class, 'member_id');
    }

    public function primaryAddress()
    {
        return $this->hasOne(Address::class, 'member_id')->where('is_primary', true);
    }

    public function employmentInfo()
    {
        return $this->hasOne(EmploymentInfo::class, 'member_id');
    }

    public function nationality()
    {
        return $this->belongsTo(Country::class, 'nationality_id');
    }

    public function birthCountry()
    {
        return $this->belongsTo(Country::class, 'birth_country_id');
    }

    public function birthState()
    {
        return $this->belongsTo(State::class, 'birth_state_id');
    }

    public function birthCity()
    {
        return $this->belongsTo(City::class, 'birth_city_id');
    }

    public function maritalStatus()
    {
        return $this->belongsTo(MaritalStatus::class, 'marital_status_id');
    }

    public function charges()
    {
        return $this->hasMany(Charge::class, 'member_id');
    }
    public function getFullNameAttribute(): string
    {
        // return "{$this->first_name} {$this->last_name} {$this->second_last_name}";
        return trim("{$this->first_name} {$this->last_name} {$this->second_last_name}");
    }

    public function getAgeAttribute(): ?int
    {
        return $this->birthdate
            ? Carbon::parse($this->birthdate)->age
            : null;
    }

    public function lockerAssignment()
    {
        return $this->hasOne(LockerAssignment::class, 'member_id')
            ->where('year', now()->year);;
    }

    public function documents()
    {
        return $this->hasMany(MemberDocument::class, 'member_id');
    }

    public function clinicalHistory()
    {
        return $this->hasOne(ClinicalHistory::class, 'member_id');
    }

    public function paymentSources()
    {
        return $this->hasMany(MemberPaymentSource::class, 'member_id');
    }

    public function defaultPaymentSource()
    {
        return $this->hasOne(MemberPaymentSource::class, 'member_id')->where('is_default', true);
    }

    public function defaultPaymentSourceForClub(int $clubId)
    {
        return $this->hasOne(MemberPaymentSource::class, 'member_id')
            ->where('club_id', $clubId)
            ->where('is_default', true);
    }

    public function conektaCustomers()
    {
        return $this->hasMany(ConektaCustomer::class, 'member_id');
    }

}
