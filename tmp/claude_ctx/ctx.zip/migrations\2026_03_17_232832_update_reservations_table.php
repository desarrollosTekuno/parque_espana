<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('reservations.reservations', function (Blueprint $table) {
            // $table->foreignId('amenity_resource_id')->nullable();
            // $table->foreign('amenity_resource_id')->references('id')->on('amenities.resources');
            $table->foreignId('amenity_resource_id')->nullable()->constrained('amenities.resources');
            // $table->unsignedBigInteger('reservation_status_id')->nullable();
            // $table->foreign('reservation_status_id')->references('id')->on('reservations.status');
            $table->foreignId('reservation_status_id')->nullable()->constrained('reservations.status');
            $table->index(['amenity_resource_id', 'reservation_date'], 'amenity_resource_id_reservation_date_index');
        });
    }

    public function down(): void
    {
        Schema::table('reservations.reservations', function (Blueprint $table) {
            $table->dropColumn('amenity_resource_id');
            $table->dropColumn('reservation_status_id');
        });
    }
};
