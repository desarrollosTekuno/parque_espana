<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CommandResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'action' => $this->action,
            'status' => $this->status,
            'device' => [
                'ip' => $this->device->ip,
                'port' => $this->device->port,
                'user' => $this->device->user,
                'password' => $this->device->password
            ],
            'data' => $this->data
        ];
    }
}
