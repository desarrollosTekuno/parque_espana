<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('members.members', function (Blueprint $table) {
            $table->string('conekta_customer_id')->nullable()->unique()->after('email');
        });
    }

    public function down(): void
    {
        Schema::table('members.members', function (Blueprint $table) {
            $table->dropColumn('conekta_customer_id');
        });
    }
};
