<?php

namespace App\Models\Memberships;

use App\Models\Catalogs\Relationship;
use App\Models\Members\Member;
use App\Models\Memberships\MembershipAccount;
use App\Traits\SerializesDates;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MembershipAccountMember extends Model
{
    use HasFactory, SerializesDates;

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = [
        'is_primary_holder'  => 'boolean',
        'access_valid_until' => 'datetime',
    ];

    protected $table = 'memberships.account_members';

    public function membershipAccount()
    {
        return $this->belongsTo(MembershipAccount::class, 'membership_account_id');
    }

    public function member()
    {
        return $this->belongsTo(Member::class, 'member_id');
    }

    public function relationship()
    {
        return $this->belongsTo(Relationship::class, 'relationship_id');
    }
}
