<?php

namespace App\Http\Controllers\Web\AdminClub;

use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use App\Models\Billing\Charge;
use Illuminate\Support\Facades\DB;
use App\Models\AdminClub\BusinessAd;
use App\Models\AdminClub\PhysicalAd;
use App\Models\AdminClub\PhysicalAdSize;
use App\Models\Billing\ChargeConcept;
use App\Models\Memberships\Membership;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;


class BusinessAdController extends Controller {

    public function __construct(){
        $this->middleware('permission:business-ads.index')->only('index');
        $this->middleware('permission:business-ads.approve')->only('approve');
        $this->middleware('permission:business-ads.reject')->only('reject');
    }

    public function index(Request $request){
        try {
            $clubId = $request->club_id ?? session('club_id');
            $driver = DB::getDriverName();
            $like   = $driver === 'pgsql' ? 'ilike' : 'like';

            // ── Anuncios digitales ──────────────────────────────────────────
            $query = BusinessAd::with(['status', 'member', 'category'])->where('club_id', $clubId);

            if ($search = $request->input("search")) {
                $query->where(function ($q) use ($search, $like) {
                    $q->where('name', $like, "%{$search}%")
                    ->orWhereHas('category', function($q) use ($search, $like){
                        $q->where('name', $like, "%{$search}%");
                    })
                    ->orWhereHas('member', function($u) use ($search, $like){
                        $u->where('first_name', $like, "%{$search}%")
                        ->orWhere('last_name', $like, "%{$search}%");
                    });
                });
            }

            $ads = $query->orderBy('id', 'desc')
                ->paginate($request->input("per_page", 10))
                ->withQueryString();

            // ── Anuncios físicos ────────────────────────────────────────────
            $physicalQuery = PhysicalAd::with('member')->where('club_id', $clubId);

            if ($physicalSearch = $request->input("physical_search")) {
                $physicalQuery->whereHas('member', function ($q) use ($physicalSearch, $like) {
                    $q->where('first_name', $like, "%{$physicalSearch}%")
                      ->orWhere('last_name', $like, "%{$physicalSearch}%");
                });
            }

            $physicalAds = $physicalQuery->orderBy('id', 'desc')
                ->paginate(
                    $request->input("physical_per_page", 10),
                    ['*'],
                    'physical_page'
                )
                ->withQueryString();

            $physicalAdSizes = PhysicalAdSize::where('club_id', $clubId)
                ->where('is_active', true)
                ->orderBy('display_order')
                ->orderBy('id')
                ->get(['id', 'label', 'price']);

            return Inertia::render('AdminClubs/BusinessAds/Index', [
                'ads'             => $ads,
                'physicalAds'     => $physicalAds,
                'physicalAdSizes' => $physicalAdSizes,
            ]);
        } catch (\Exception $e) {
            report($e);
            return Inertia::render('AdminClubs/BusinessAds/Index', [
                'ads'             => ['data' => [], 'total' => 0],
                'physicalAds'     => ['data' => [], 'total' => 0],
                'physicalAdSizes' => [],
                'messageError'    => $e->getMessage(),
            ]);
        }
    }

    /*   Aprobar anuncio   */
    public function approve($id){
        try {
            DB::beginTransaction();

            $ad = BusinessAd::with('member.accountMemberships')
                ->lockForUpdate()
                ->findOrFail($id);

            // Solo se aprueba una solicitud pendiente: evita duplicar el
            // cargo si se da clic dos veces o el anuncio ya avanzó de estado.
            if ($ad->status_id !== 1) {
                throw new \Exception('Solo se pueden aprobar anuncios pendientes.');
            }

            if (!$ad->member) {
                throw new \Exception('El anuncio no tiene miembro asociado');
            }

            // El cargo debe colgar de la membresía del socio EN EL PARQUE del
            // anuncio (no de la primera que encuentre): al cobrar,
            // PaymentRegistrationService::ensureChargesBelongToClub compara
            // charge->membership->club_id contra el parque de la caja, y
            // Cobranza agrupa el renglón por ese mismo club.
            $accountIds = $ad->member->accountMemberships->pluck('membership_account_id');
            $membership = Membership::query()
                ->whereIn('membership_account_id', $accountIds)
                ->where('club_id', $ad->club_id)
                ->whereIn('status', ['active', 'suspended'])
                ->orderByDesc('is_primary')
                ->first();
            if (!$membership) {
                throw new \Exception('El socio no tiene una membresía activa en el parque de este anuncio.');
            }
            $accountMembership = (object) ['membership_account_id' => $membership->membership_account_id];

            $ad->update([
                'status_id' => 3, // approved
                'approved_at' => now()
            ]);
            $concept = ChargeConcept::query()
                ->with('clubAmounts')
                ->where('code', 'BUSINESS_AD')
                ->firstOrFail();
            $conceptAmount = $concept->resolveAmountForClub($ad->club_id);

            if ($conceptAmount === null) {
                throw new \Exception('El concepto de cobro para negocio/publicidad no tiene monto configurado.');
            }

            Charge::create([
                'membership_account_id' => $accountMembership->membership_account_id,
                'membership_id' => $membership->id,
                'member_id' => $ad->member_id,
                'concept_id' => $concept->id,
                'description' => $concept->description,
                'amount' => $conceptAmount,
                'balance' => $conceptAmount,
                'issue_date' => now(),
                'due_date' => now()->addDays(7),
                'period_year' => now()->year,
                'period_month' => now()->month,
                'allows_partial_payments' => false,
                'status' => 'pending',
                'metadata' => [
                    'business_ad_id' => $ad->id,
                    'club_id' => $ad->club_id,
                    'concept_amount_source' => 'club_or_default',
                ]
            ]);
            DB::commit();
            return back()->with('success','Anuncio aprobado correctamente');

        } catch (\Exception $e) {
            DB::rollBack();
            report($e);
            //dd($e->getMessage());
            return back()->withErrors([
                'messageError' => $e->getMessage()
            ]);
        }
    }

    /*   Rechazar anuncio   */
    public function reject(Request $request, $id){
        try {
            DB::beginTransaction();

            $ad = BusinessAd::findOrFail($id);
            $ad->update([
                'status_id' => 2, // rejected
                'rejection_reason' => $request->reason,
            ]);
            DB::commit();
            return back()->with('success','Anuncio rechazado correctamente');

        } catch (\Exception $e) {
            DB::rollBack();
            report($e);

            return back()->withErrors([
                'messageError' => $e->getMessage()
            ]);
        }
    }
}
