<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::table('amenities.amenities', function (Blueprint $table) {
            $table->text('description')->nullable()->change();
            $table->dropColumn('capacity');
        });
    }

    public function down(): void
    {
        Schema::table('amenities.amenities', function (Blueprint $table) {
            $table->string('description')->nullable()->change();
            $table->string('reservation_type')->change();
            $table->integer('capacity')->nullable();
        });
    }
};
