<?php

namespace App\Http\Controllers\Web\AdminClub\Feedback;

use App\Models\Feedback\Priority;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Inertia\Inertia;

class FeedbackPriorityController extends Controller {

    public function __construct() {
        $this->middleware('permission:feedback-priorities.index')->only('index');
        $this->middleware('permission:feedback-priorities.store')->only('store');
        $this->middleware('permission:feedback-priorities.update')->only('update');
        $this->middleware('permission:feedback-priorities.destroy')->only('destroy');
    }

    public function index(Request $request) {
        try {
            $driver = DB::getDriverName();

            $query = Priority::query();

            if ($search = trim($request->input('search'))) {
                $operator = $driver == 'pgsql' ? 'ilike' : 'like';

                $query->where(function ($q) use ($search, $operator) {
                    $q->where('name', $operator, "%{$search}%")
                        ->orWhere('code', $operator, "%{$search}%");
                });
            }

            $priorities = $query
                ->orderBy('sort_order', 'asc')
                ->orderBy('id', 'desc')
                ->paginate($request->input('per_page', 10))
                ->withQueryString();

            return Inertia::render('AdminClubs/FeedbackPriorities/Index', [
                'priorities' => $priorities,
            ]);

        } catch (\Exception $e) {
            report($e);

            return Inertia::render('AdminClubs/FeedbackPriorities/Index', [
                'priorities' => [
                    'data' => [],
                    'total' => 0,
                ],
                'messageError' => $e->getMessage(),
            ]);
        }
    }

    public function store(Request $request) {
        $request->validate([
            'name' => ['required', 'string', 'max:25'],
            'code' => ['required', 'string', 'max:25'],
            'is_active' => 'boolean',
        ]);

        try {
            Priority::create([
                'name' => $request->name,
                'code' => $request->code,
                'is_active' => $request->boolean('is_active', true),
            ]);

            return back()->with('success', 'Prioridad creada correctamente');

        } catch (\Exception $e) {
            report($e);

            return back()->withErrors([
                'messageError' => 'Error al crear la prioridad',
                'exception' => $e->getMessage(),
            ]);
        }
    }

    public function update(Request $request, $id) {
        $request->validate([
            'name' => 'required|string|max:25',
        ]);

        try {
            $priority = Priority::findOrFail($id);

            $priority->update([
                'name' => $request->name,
            ]);

            return back()->with('success', 'Prioridad actualizada correctamente');

        } catch (\Exception $e) {
            report($e);

            return back()->withErrors([
                'messageError' => 'Error al actualizar la prioridad',
                'exception' => $e->getMessage(),
            ]);
        }
    }

    public function destroy($id) {
        try {
            $priority = Priority::findOrFail($id);
            $priority->delete();

            return back()->with('success', 'Prioridad eliminada correctamente');

        } catch (\Exception $e) {
            report($e);

            return back()->withErrors([
                'messageError' => 'Error al eliminar la prioridad',
                'exception' => $e->getMessage(),
            ]);
        }
    }
}
