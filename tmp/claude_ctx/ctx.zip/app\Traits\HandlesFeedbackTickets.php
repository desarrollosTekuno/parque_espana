<?php

namespace App\Traits;

use App\Models\Feedback\Attachment;
use App\Models\Feedback\Ticket;
use App\Models\Administrator\Club;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

trait HandlesFeedbackTickets {

    protected function createTicketNumber(int $clubId, int $maxAttempts = 3): ?string {
        $clubCode = Club::whereKey($clubId)->value('code');

        if (!$clubCode) {
            return null;
        }

        $clubPrefix = strtoupper($clubCode);
        $year = now()->format('y');

        for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
            $lastTicket = Ticket::where('club_id', $clubId)
                ->whereYear('ticket_date', now()->year)
                ->orderBy('id', 'desc')
                ->first();

            $nextNumber = $lastTicket ? ((int) substr($lastTicket->ticket_number, -4)) + 1 : 1;
            $candidate = 'FB-' . $clubPrefix . '-' . $year . '-' . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

            if (!Ticket::where('ticket_number', $candidate)->exists()) {
                return $candidate;
            }
        }

        return null;
    }

    protected function storeFileAttachments(Ticket $ticket, array $files): void {
        $ticketFolder = 'Feedback/' . $ticket->ticket_number;

        foreach ($files as $file) {
            if (!$file instanceof UploadedFile) {
                continue;
            }

            $filename    = Str::uuid() . '.' . $file->getClientOriginalExtension();
            $storagePath = $ticketFolder . '/' . $filename;

            Storage::disk('spaces')->putFileAs($ticketFolder, $file, $filename, 'public');

            Attachment::create([
                'ticket_id'           => $ticket->id,
                'file_name'           => $file->getClientOriginalName(),
                'file_path'           => $storagePath,
                'file_type'           => $file->getClientMimeType(),
                'file_size'           => $file->getSize(),
                'storage_disk'        => 'spaces',
                'uploaded_by_user_id' => Auth::id(),
            ]);
        }
    }

    protected function getAttachmentFiles(Request $request): array {
        $files = $request->file('attachments', []);

        if ($files === null) {
            return [];
        }

        if ($files instanceof UploadedFile) {
            return [$files];
        }

        if (!is_array($files)) {
            return [];
        }

        return array_values(array_filter($files, fn ($file) => $file instanceof UploadedFile));
    }
}
