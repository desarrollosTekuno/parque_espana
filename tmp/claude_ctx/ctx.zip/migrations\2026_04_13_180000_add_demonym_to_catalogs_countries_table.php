<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('catalogs.countries', function (Blueprint $table) {
            $table->string('demonym')->nullable()->after('nationality');
        });
    }

    public function down(): void
    {
        Schema::table('catalogs.countries', function (Blueprint $table) {
            $table->dropColumn('demonym');
        });
    }
};
